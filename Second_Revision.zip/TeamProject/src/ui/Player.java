package ui;

public interface Player {

}
